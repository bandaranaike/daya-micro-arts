<?php

namespace App\Config;

enum IntSystemConfigEnum: int
{
    case DEFAULT_PAGINATION_PER_PAGE = 20;
}
