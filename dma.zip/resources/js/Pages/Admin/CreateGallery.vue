<template>

</template>

<script>
export default {
    name: "CreateGallery"
}
</script>

<style scoped>

</style>
